
CREATE TABLE users(id SERIAL PRIMARY KEY,email TEXT,password TEXT,role TEXT DEFAULT 'customer');
CREATE TABLE products(id SERIAL PRIMARY KEY,name TEXT,price INT,stock INT);
CREATE TABLE orders(id SERIAL PRIMARY KEY,user_id INT,total INT,status TEXT);
