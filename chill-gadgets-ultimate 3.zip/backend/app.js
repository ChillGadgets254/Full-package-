
const express=require('express');
const app=express();
app.use(express.json());
app.get('/api/health',(req,res)=>res.json({ok:true}));
app.listen(5000,()=>console.log('API running'));
